# ================================================================
# FutbolTrack - app/__init__.py
# Fabrica de la aplicacion Flask con Flask-Session (fix #1)
# ================================================================
from flask import Flask
from flask_cors import CORS
from flask_session import Session
from config import Config


def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)

    # CORS: permite credenciales desde el frontend React
    CORS(app, origins=["http://localhost:5173", "http://127.0.0.1:5173"], supports_credentials=True)

    # Sesiones del lado del servidor (filesystem)
    Session(app)

    # Registrar blueprints
    from app.routes.auth          import auth_bp
    from app.routes.jugadores     import jugadores_bp
    from app.routes.entrenamientos import entrenamientos_bp
    from app.routes.asistencia    import asistencia_bp
    from app.routes.catalogos     import catalogos_bp
    from app.routes.sesiones      import sesiones_bp
    from app.routes.entrenadores   import entrenadores_bp

    app.register_blueprint(auth_bp,           url_prefix="/api/auth")
    app.register_blueprint(jugadores_bp,      url_prefix="/api/jugadores")
    app.register_blueprint(entrenamientos_bp, url_prefix="/api/entrenamientos")
    app.register_blueprint(asistencia_bp,     url_prefix="/api/asistencia")
    app.register_blueprint(catalogos_bp,      url_prefix="/api")
    app.register_blueprint(sesiones_bp,       url_prefix="/api/sesion")
    app.register_blueprint(entrenadores_bp,   url_prefix="/api/entrenadores")

    return app