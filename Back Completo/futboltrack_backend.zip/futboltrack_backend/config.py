# ================================================================
# FutbolTrack - config.py
# Lee variables del .env  (fix #6: DEBUG y PASSWORD desde env)
# ================================================================
import os
from dotenv import load_dotenv

load_dotenv()


class Config:
    # MySQL
    MYSQL_HOST     = os.getenv("MYSQL_HOST", "127.0.0.1")
    MYSQL_PORT     = int(os.getenv("MYSQL_PORT", 3306))
    MYSQL_USER     = os.getenv("MYSQL_USER", "root")
    MYSQL_PASSWORD = os.getenv("MYSQL_PASSWORD", "")
    MYSQL_DB       = os.getenv("MYSQL_DB", "mydb")

    # MongoDB
    MONGO_URI = os.getenv("MONGO_URI", "mongodb://127.0.0.1:27017")
    MONGO_DB  = os.getenv("MONGO_DB", "futboltrack")

    # Flask
    SECRET_KEY  = os.getenv("SECRET_KEY", "cambia-esta-clave-en-produccion")
    DEBUG       = os.getenv("FLASK_DEBUG", "False").lower() == "true"
    PORT        = int(os.getenv("FLASK_PORT", 5000))

    # Flask-Session (servidor, no cookie)
    SESSION_TYPE            = "filesystem"
    SESSION_FILE_DIR        = ".flask_sessions"
    SESSION_PERMANENT       = False
    SESSION_USE_SIGNER      = True
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
